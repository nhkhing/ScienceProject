from datetime import datetime
from app import db

class Analysis(db.Model):
    """Model for storing potato plant disease analysis results"""
    id = db.Column(db.Integer, primary_key=True)
    image_path = db.Column(db.String(255), nullable=False)
    disease = db.Column(db.String(100), nullable=True)
    confidence = db.Column(db.Float, nullable=True)
    recommendations = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Analysis {self.id}: {self.disease}>'

    def to_dict(self):
        return {
            'id': self.id,
            'image_path': self.image_path,
            'disease': self.disease,
            'confidence': self.confidence,
            'recommendations': self.recommendations,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S')
        }
