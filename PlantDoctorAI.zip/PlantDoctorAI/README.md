# PlantDoctor

PlantDoctor is an AI-powered application that detects potato plant diseases with high accuracy using machine learning. The app allows users to upload images or use their device camera to capture photos of potato plants for analysis.

## Features

- Upload images of potato plants for disease detection
- Use your device camera to take photos directly in the app
- Get accurate disease identification with confidence ratings
- Receive personalized treatment recommendations
- View analysis history

## Deployment to Netlify

This project is configured for seamless deployment on Netlify. Follow these steps to deploy:

1. Fork or clone this repository
2. Login to your Netlify account
3. Click "New site from Git"
4. Select your repository
5. Netlify will automatically detect the configuration
6. Set the following environment variables in the Netlify dashboard (Site settings > Build & deploy > Environment):
   - `DATABASE_URL`: Your PostgreSQL database connection string
   - `SESSION_SECRET`: A secure random string for session security (can be generated with `openssl rand -hex 32`)
   - `NETLIFY`: Set to "true" to enable Netlify-specific adaptations
7. Click "Deploy site"

## Database Setup

This application uses PostgreSQL. Here's how to set it up for deployment:

### Option 1: Heroku Postgres
1. Create a Heroku account if you don't have one
2. Install the Heroku CLI
3. Create a new app: `heroku create your-app-name`
4. Add Postgres: `heroku addons:create heroku-postgresql:hobby-dev`
5. Get your DATABASE_URL: `heroku config:get DATABASE_URL`
6. Add this URL to your Netlify environment variables

### Option 2: Neon or Supabase
1. Create an account at neon.tech or supabase.com
2. Create a new PostgreSQL database
3. Get the connection string
4. Add this URL to your Netlify environment variables

### Required Schema
The application will automatically create the necessary tables on first run.

## Local Development

To run the application locally:

1. Install the required packages: `pip install -r requirements.txt`
2. Set up the PostgreSQL database or use the SQLite fallback
3. Run the application: `gunicorn --bind 0.0.0.0:5000 main:app`

## Netlify Optimization Notes

For Netlify deployment, we've made some optimizations:

1. **TensorFlow Removal**: We use PIL/Pillow for image processing instead of TensorFlow in the Netlify deployment, significantly reducing bundle size and cold start times.

2. **Serverless Function Handler**: The `netlify/functions/api.py` file contains a specialized WSGI adapter for the Flask app that handles various edge cases in the serverless environment.

3. **File Upload Handling**: File uploads are stored in Netlify's `/tmp` directory as serverless functions have limited write access.

## Troubleshooting

If you encounter issues with the Netlify deployment:

1. **Database Connection**: Run the database test script to verify connectivity:
   ```
   cd netlify
   python test_db.py
   ```

2. **Function Timeouts**: If image processing takes too long, try increasing the function timeout in `netlify.toml` (current default: 30 seconds).

3. **Missing Environment Variables**: Check that all required environment variables are set in the Netlify dashboard.

4. **Cold Start Performance**: The first request after deployment might be slow as the function cold-starts. Subsequent requests should be faster.

## Technologies Used

- Flask: Backend web framework
- SQLAlchemy: Database ORM
- PostgreSQL: Database
- Machine Learning: AI model for disease detection
- Bootstrap: Frontend styling
- JavaScript: Client-side interactivity

## Project Structure

- `main.py`: Application entry point
- `app.py`: Flask application configuration
- `routes.py`: Application routes and controllers
- `models.py`: Database models
- `ml_model.py`: Machine learning model for disease detection
- `templates/`: HTML templates
- `static/`: Static assets (CSS, JS, images)
- `netlify/`: Netlify deployment configuration

## License

MIT