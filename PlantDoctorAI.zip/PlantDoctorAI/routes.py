import os
import uuid
import base64
from datetime import datetime
from flask import render_template, request, redirect, url_for, flash, jsonify, session
from werkzeug.utils import secure_filename
import logging

from app import app, db
from models import Analysis
from ml_model import potato_disease_model, POTATO_DISEASES

logger = logging.getLogger(__name__)

def allowed_file(filename):
    """Check if the file extension is allowed"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def save_base64_image(base64_string):
    """Save base64 encoded image to file"""
    try:
        # Generate a unique filename
        filename = f"{uuid.uuid4().hex}.jpg"
        
        # Check if running on Netlify
        if os.environ.get('NETLIFY'):
            # Use Netlify temp directory for serverless functions
            temp_dir = os.environ.get('TEMP', '/tmp')
            uploads_dir = os.path.join(temp_dir, 'uploads')
            os.makedirs(uploads_dir, exist_ok=True)
            filepath = os.path.join(uploads_dir, filename)
        else:
            # Use regular uploads directory
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            
        # Remove the data URL prefix if present
        if ',' in base64_string:
            base64_string = base64_string.split(',')[1]
        
        # Decode and save the image
        with open(filepath, "wb") as f:
            f.write(base64.b64decode(base64_string))
        
        return filepath
    except Exception as e:
        logger.error(f"Error saving base64 image: {str(e)}")
        return None

@app.route('/')
def index():
    """Render the home page"""
    return render_template('index.html')

@app.route('/about')
def about():
    """Render the about page"""
    return render_template('about.html')

@app.route('/history')
def history():
    """Show history of analyzed images"""
    analyses = Analysis.query.order_by(Analysis.created_at.desc()).all()
    return render_template('history.html', analyses=analyses)

@app.route('/upload', methods=['POST'])
def upload_file():
    """Handle image uploads from the form"""
    try:
        # Check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part', 'error')
            return redirect(url_for('index'))
        
        file = request.files['file']
        
        # If user does not select file, browser may submit an empty file
        if file.filename == '':
            flash('No selected file', 'error')
            return redirect(url_for('index'))
        
        if file and allowed_file(file.filename):
            # Secure the filename and save the file
            filename = secure_filename(file.filename)
            unique_filename = f"{uuid.uuid4().hex}_{filename}"
            
            # Check if running on Netlify
            if os.environ.get('NETLIFY'):
                # Use Netlify temp directory for serverless functions
                temp_dir = os.environ.get('TEMP', '/tmp')
                uploads_dir = os.path.join(temp_dir, 'uploads')
                os.makedirs(uploads_dir, exist_ok=True)
                filepath = os.path.join(uploads_dir, unique_filename)
            else:
                # Use regular uploads directory
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
                
            file.save(filepath)
            
            # Process the image with the ML model
            result = process_image(filepath)
            
            if result['success']:
                return redirect(url_for('show_result', analysis_id=result['analysis_id']))
            else:
                flash(result['error'], 'error')
                return redirect(url_for('index'))
        else:
            flash('File type not allowed. Please upload a JPG, JPEG, or PNG file.', 'error')
            return redirect(url_for('index'))
    
    except Exception as e:
        logger.error(f"Upload error: {str(e)}")
        flash(f"An error occurred during upload: {str(e)}", 'error')
        return redirect(url_for('index'))

@app.route('/upload-camera', methods=['POST'])
def upload_camera():
    """Handle camera image uploads (base64 encoded)"""
    try:
        # Get the base64 data from the request
        image_data = request.form.get('image')
        if not image_data:
            return jsonify({
                'success': False,
                'error': 'No image data received'
            })
        
        # Save the base64 image to a file
        filepath = save_base64_image(image_data)
        if not filepath:
            return jsonify({
                'success': False,
                'error': 'Failed to save image'
            })
        
        # Process the image with the ML model
        result = process_image(filepath)
        
        if result['success']:
            return jsonify({
                'success': True,
                'redirect': url_for('show_result', analysis_id=result['analysis_id'])
            })
        else:
            return jsonify({
                'success': False,
                'error': result['error']
            })
    
    except Exception as e:
        logger.error(f"Camera upload error: {str(e)}")
        return jsonify({
            'success': False,
            'error': f"An error occurred: {str(e)}"
        })

def process_image(filepath):
    """
    Process the image with the ML model and save results to database
    
    Args:
        filepath: Path to the uploaded image
        
    Returns:
        Dictionary with processing results
    """
    try:
        # Ensure the model is loaded
        if not potato_disease_model.load():
            return {
                'success': False,
                'error': 'Failed to load disease detection model'
            }
        
        # Get prediction from model
        prediction = potato_disease_model.predict(filepath)
        
        if not prediction['success']:
            return {
                'success': False,
                'error': prediction.get('error', 'Analysis failed')
            }
        
        # Create relative path for database storage
        relative_path = os.path.relpath(filepath, start=os.path.dirname(app.root_path))
        
        # Save results to database
        analysis = Analysis(
            image_path=relative_path,
            disease=prediction['disease'],
            confidence=prediction['confidence'],
            recommendations="\n".join(prediction['recommendations'])
        )
        
        db.session.add(analysis)
        db.session.commit()
        
        return {
            'success': True,
            'analysis_id': analysis.id
        }
    
    except Exception as e:
        logger.error(f"Image processing error: {str(e)}")
        return {
            'success': False,
            'error': f"Image processing failed: {str(e)}"
        }

@app.route('/result/<int:analysis_id>')
def show_result(analysis_id):
    """Display the analysis result"""
    analysis = Analysis.query.get_or_404(analysis_id)
    
    # Get disease information from the model
    disease = analysis.disease
    disease_info = POTATO_DISEASES.get(disease, {
        'description': 'No information available for this condition.',
        'recommendations': ['Consult with a plant pathologist for accurate diagnosis.']
    })
    
    return render_template(
        'result.html',
        analysis=analysis,
        description=disease_info['description'],
        recommendations=disease_info['recommendations']
    )

@app.route('/delete/<int:analysis_id>', methods=['POST'])
def delete_analysis(analysis_id):
    """Delete an analysis from history"""
    analysis = Analysis.query.get_or_404(analysis_id)
    
    try:
        # Try to delete the image file
        if os.path.exists(analysis.image_path):
            os.remove(analysis.image_path)
        
        # Delete from database
        db.session.delete(analysis)
        db.session.commit()
        
        flash('Analysis deleted successfully', 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting analysis: {str(e)}")
        flash(f"Error deleting analysis: {str(e)}", 'error')
    
    return redirect(url_for('history'))

@app.errorhandler(404)
def page_not_found(e):
    """Handle 404 errors"""
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    """Handle 500 errors"""
    logger.error(f"Server error: {str(e)}")
    return render_template('500.html'), 500
