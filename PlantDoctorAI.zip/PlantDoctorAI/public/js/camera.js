// Enhanced camera functionality for PlantDoctor app with modern animations

let stream = null;
let video = null;
let canvas = null;
let captureBtn = null;
let retakeBtn = null;
let analyzeBtn = null;
let isCaptured = false;
let cameraFocus = null;

document.addEventListener('DOMContentLoaded', function() {
  // Initialize camera tab functionality with animation
  const cameraTab = document.getElementById('camera-tab');
  if (cameraTab) {
    cameraTab.addEventListener('click', () => {
      // Add animation before initializing
      setTimeout(() => {
        initCamera();
      }, 300);
    });
  }
  
  // Initialize camera elements
  video = document.getElementById('video');
  canvas = document.getElementById('canvas');
  captureBtn = document.getElementById('capture-btn');
  retakeBtn = document.getElementById('retake-btn');
  analyzeBtn = document.getElementById('analyze-btn');
  
  // Set up button event listeners with animations
  if (captureBtn) {
    captureBtn.addEventListener('click', () => {
      captureBtn.classList.add('pulse-animation');
      setTimeout(() => {
        captureBtn.classList.remove('pulse-animation');
        captureImage();
      }, 300);
    });
  }
  
  if (retakeBtn) {
    retakeBtn.addEventListener('click', () => {
      retakeBtn.classList.add('pulse-animation');
      setTimeout(() => {
        retakeBtn.classList.remove('pulse-animation');
        retakeImage();
      }, 300);
    });
  }
  
  if (analyzeBtn) {
    analyzeBtn.addEventListener('click', () => {
      analyzeBtn.classList.add('pulse-animation');
      setTimeout(() => {
        analyzeBtn.classList.remove('pulse-animation');
        analyzeImage();
      }, 300);
    });
  }
  
  // If camera tab is active by default, initialize camera
  if (cameraTab && cameraTab.classList.contains('active')) {
    initCamera();
  }
  
  // Create camera focus element
  createCameraFocus();
});

// Create camera focus animation
function createCameraFocus() {
  const cameraContainer = document.getElementById('camera-container');
  if (!cameraContainer) return;
  
  cameraFocus = document.createElement('div');
  cameraFocus.className = 'camera-focus';
  cameraFocus.style.position = 'absolute';
  cameraFocus.style.top = '50%';
  cameraFocus.style.left = '50%';
  cameraFocus.style.width = '150px';
  cameraFocus.style.height = '150px';
  cameraFocus.style.border = '2px solid rgba(76, 175, 80, 0.8)';
  cameraFocus.style.borderRadius = '5px';
  cameraFocus.style.transform = 'translate(-50%, -50%)';
  cameraFocus.style.display = 'none';
  cameraFocus.style.pointerEvents = 'none';
  
  cameraContainer.style.position = 'relative';
  cameraContainer.appendChild(cameraFocus);
}

// Show camera focus animation
function showCameraFocus() {
  if (!cameraFocus) return;
  
  cameraFocus.style.display = 'block';
  cameraFocus.style.animation = 'camera-focus 2s infinite';
  
  // Add keyframes if not already added
  if (!document.getElementById('camera-focus-keyframes')) {
    const style = document.createElement('style');
    style.id = 'camera-focus-keyframes';
    style.textContent = `
      @keyframes camera-focus {
        0% { box-shadow: 0 0 0 0 rgba(76, 175, 80, 0.2); }
        70% { box-shadow: 0 0 0 10px rgba(76, 175, 80, 0); }
        100% { box-shadow: 0 0 0 0 rgba(76, 175, 80, 0); }
      }
    `;
    document.head.appendChild(style);
  }
}

// Hide camera focus animation
function hideCameraFocus() {
  if (cameraFocus) {
    cameraFocus.style.display = 'none';
  }
}

// Initialize the camera stream with enhanced UI
function initCamera() {
  if (video && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    // Stop any existing stream
    stopCamera();
    
    // Set up camera controls
    if (retakeBtn) retakeBtn.style.display = 'none';
    if (analyzeBtn) analyzeBtn.style.display = 'none';
    if (captureBtn) {
      captureBtn.style.display = 'block';
      captureBtn.classList.add('fade-in');
    }
    
    isCaptured = false;
    
    // Show loading animation in video container while camera initializes
    const cameraContainer = document.getElementById('camera-container');
    if (cameraContainer) {
      const loadingOverlay = document.createElement('div');
      loadingOverlay.className = 'camera-loading-overlay';
      loadingOverlay.style.position = 'absolute';
      loadingOverlay.style.top = '0';
      loadingOverlay.style.left = '0';
      loadingOverlay.style.width = '100%';
      loadingOverlay.style.height = '100%';
      loadingOverlay.style.background = 'rgba(0, 0, 0, 0.7)';
      loadingOverlay.style.display = 'flex';
      loadingOverlay.style.alignItems = 'center';
      loadingOverlay.style.justifyContent = 'center';
      loadingOverlay.style.zIndex = '10';
      loadingOverlay.style.borderRadius = 'var(--border-radius)';
      
      loadingOverlay.innerHTML = `
        <div class="text-center">
          <div class="spinner-border text-info" role="status">
            <span class="visually-hidden">Loading camera...</span>
          </div>
          <p class="text-white mt-2">Initializing camera...</p>
        </div>
      `;
      
      cameraContainer.style.position = 'relative';
      cameraContainer.appendChild(loadingOverlay);
    }
    
    // Request camera access
    navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: 'environment', // Prefer back camera on mobile
        width: { ideal: 1280 },
        height: { ideal: 720 }
      },
      audio: false
    })
    .then(function(mediaStream) {
      stream = mediaStream;
      video.srcObject = mediaStream;
      
      // Add fade-in animation
      video.style.opacity = '0';
      video.onloadedmetadata = function(e) {
        video.play();
        
        // Remove loading overlay
        const loadingOverlay = document.querySelector('.camera-loading-overlay');
        if (loadingOverlay) {
          setTimeout(() => {
            loadingOverlay.style.opacity = '0';
            loadingOverlay.style.transition = 'opacity 0.5s ease';
            
            setTimeout(() => {
              loadingOverlay.remove();
              
              // Fade in video
              video.style.opacity = '1';
              video.style.transition = 'opacity 0.5s ease';
              
              // Show camera focus
              setTimeout(() => {
                showCameraFocus();
              }, 500);
            }, 500);
          }, 500);
        }
      };
    })
    .catch(function(err) {
      console.error("Error accessing camera:", err);
      showCameraError();
      
      // Remove loading overlay
      const loadingOverlay = document.querySelector('.camera-loading-overlay');
      if (loadingOverlay) {
        loadingOverlay.remove();
      }
    });
  } else {
    showCameraError();
  }
}

// Stop the camera stream
function stopCamera() {
  if (stream) {
    stream.getTracks().forEach(track => {
      track.stop();
    });
    stream = null;
    if (video) video.srcObject = null;
  }
  
  // Hide camera focus
  hideCameraFocus();
}

// Show camera error message with animation
function showCameraError() {
  const cameraContainer = document.getElementById('camera-container');
  if (cameraContainer) {
    // Create error message with animation
    cameraContainer.innerHTML = `
      <div class="alert alert-danger text-center fade-in">
        <i class="fas fa-exclamation-circle me-2"></i>
        Camera access failed. Please ensure your browser has permission to access the camera,
        or try uploading an image instead.
      </div>
    `;
  }
}

// Capture image from video with animation
function captureImage() {
  if (!video || !canvas) return;
  
  // Create capture animation
  const cameraContainer = document.getElementById('camera-container');
  if (cameraContainer) {
    const captureFlash = document.createElement('div');
    captureFlash.className = 'capture-flash';
    captureFlash.style.position = 'absolute';
    captureFlash.style.top = '0';
    captureFlash.style.left = '0';
    captureFlash.style.width = '100%';
    captureFlash.style.height = '100%';
    captureFlash.style.backgroundColor = 'white';
    captureFlash.style.opacity = '0';
    captureFlash.style.zIndex = '5';
    captureFlash.style.pointerEvents = 'none';
    
    cameraContainer.appendChild(captureFlash);
    
    // Flash animation
    setTimeout(() => {
      captureFlash.style.opacity = '0.8';
      captureFlash.style.transition = 'opacity 0.1s ease-out';
      
      setTimeout(() => {
        captureFlash.style.opacity = '0';
        captureFlash.style.transition = 'opacity 0.3s ease-in';
        
        setTimeout(() => {
          captureFlash.remove();
        }, 300);
      }, 100);
    }, 0);
  }
  
  // Play camera shutter sound
  const shutterSound = new Audio('data:audio/wav;base64,//uQRAAAAWMSLwUIYAAsYkXgoQwAEaYLWfkWgAI0wWs/ItAAAGDgYtAgAyN+QWaAAihwMWm4G8QQRDiMcCBcH3Cc+CDv/7xA4Tvh9Rz/y8QADBwMWgQAZG/ILNAARQ4GLTcDeIIIhxGOBAuD7hOfBB3/94gcJ3w+o5/5eIAIAAAVwWgQAVQ2ORaIQwEMAJiDg95G4nQL7mQVWI6GwRcfsZAcsKkJvxgxEjzFUgfHoSQ9Qq7KNwqHwuB13MA4a1q/DmBrHgPcmjiGoh//EwC5nGPEmS4RcfkVKOhJf+WOgoxJclFz3kgn//dBA+ya1GhurNn8zb//9NNutNuhz31f////9vt///z+IdAEAAAK4LQIAKobHItEIYCGAExBwe8jcToF9zIKrEdDYIuP2MgOWFSE34wYiR5iqQPj0JIeoVdlG4VD4XA67mAcNa1fhzA1jwHuTRxDUQ//iYBczjHiTJcIuPyKlHQkv/LHQUYkuSi57yQT//uggfZNajQ3Vmz+Zt//+mm3Wm3Q576v////+32///5/EOgAAADVghQAAAAA//uQZAUAB1WI0PZugAAAAAoQwAAAEk3nRd2qAAAAACiDgAAAAAAABCqEEQRLCgwpBGMlJkIz8jKhGvj4k6jzRnqasNKIeoh5gI7BJaC1A1AoNBjJgbyApVS4IDlZgDU5WUAxEKDNmmALHzZp0Fkz1FMTmGFl1FMEyodIavcCAUHDWrKAIA4aa2oCgILEBupZgHvAhEBcZ6joQBxS76AgccrFlczBvKLC0QI2cBoCFvfTDAo7eoOQInqDPBtvrDEZBNYN5xwNwxQRfw8ZQ5wQVLvO8OYU+mHvFLlDh05Mdg7BT6YrRPpCBznMB2r//xKJjyyOh+cImr2/4doscwD6neZjuZR4AgAABYAAAABy1xcdQtxYBYYZdifkUDgzzXaXn98Z0oi9ILU5mBjFANmRwlVJ3/6jYDAmxaiDG3/6xjQQCCKkRb/6kg/wW+kSJ5//rLobkLSiKmqP/0ikJuDaSaSf/6JiLYLEYnW/+kXg1WRVJL/9EmQ1YZIsv/6Qzwy5qk7/+tEU0nkls3/zIUMPKNX/6yZLf+kFgAfgGyLFAUwY//uQZAUABcd5UiNPVXAAAApAAAAAE0VZQKw9ISAAACgAAAAAVQIygIElVrFkBS+Jhi+EAuu+lKAkYUEIsmEAEoMeDmCETMvfSHTGkF5RWH7kz/ESHWPAq/kcCRhqBtMdokPdM7vil7RG98A2sc7zO6ZvTdM7pmOUAZTnJW+NXxqmd41dqJ6mLTXxrPpnV8ij8+PDw7Fpji3fEA4z/PEJ6YOB5hKh4dj3EvXhxPqH/SKUY3rJ7srZ4FZnh1PMAtPhwP6fl2PMJMPDgeQ4rY8YT6Gzao0eAEA409DuggmTnFnOcSCiEiLMgxCiTI6Cq5DZUd3Qmp10vO0LaLTd2cjN4fOumlc7lUYbSQcZFkutRG7g6JKZKy0RmdLY680CDnEJ+UMkpFFe1RN7nxdVpXrC4aTtnaurOnYercZg2YVmLN/d/gczfEimrE/fs/bOuq29Zmn8tloORaXgZgGa78yO9/cnXm2BpaGvq25Dv9S4E9+5SIc9PqupJKhYFSSl47+Qcr1mYNAAAAeNptw0cKwkAAAMDZJA8Q7OUJvkLsPfZ6zFVERPy8qHh2YER+3i/BP83vIBLLySsoKimrqKqpa2hp6+jq6RsYGhmbmJqZSy0sraxtbO3sHRydnEMU4uR6yx7JJXveP7WrDycAAAAAAAH//wACeNpjYGRgYOABYhkgZgJCZgZNBkYGLQZtIJsFLMYAAAw3ALgAeNolizEKgDAQBCchRbC2sFER0YD6qVQiBCv/H9ezGI6Z5XBAw8CBK/m5iQQVauVbXLnOrMZv2oLdKFa8Pjuru2hJzGabmOSLzNMzvutpB3N42mNgZGBg4GKQYzBhYMxJLMlj4GBgAYow/P/PAJJhLM6sSoWKfWCAAwDAjgbRAAB42mNgYGBkAIIbCZo5IPrmUn0hGA0AO8EFTQAA');
  shutterSound.play().catch(e => {
    // Ignore audio playback errors
  });
  
  // Set canvas dimensions to match video
  const videoWidth = video.videoWidth;
  const videoHeight = video.videoHeight;
  canvas.width = videoWidth;
  canvas.height = videoHeight;
  
  // Draw the current video frame to the canvas
  const context = canvas.getContext('2d');
  context.drawImage(video, 0, 0, videoWidth, videoHeight);
  
  // Hide camera focus
  hideCameraFocus();
  
  // Display the captured image with smooth transition
  video.style.opacity = '0';
  video.style.transition = 'opacity 0.3s ease';
  
  setTimeout(() => {
    video.style.display = 'none';
    canvas.style.display = 'block';
    canvas.style.opacity = '0';
    
    setTimeout(() => {
      canvas.style.opacity = '1';
      canvas.style.transition = 'opacity 0.3s ease';
    }, 50);
  }, 300);
  
  // Update UI with smooth transitions
  if (captureBtn) {
    captureBtn.style.opacity = '0';
    captureBtn.style.transition = 'opacity 0.3s ease';
    setTimeout(() => {
      captureBtn.style.display = 'none';
      
      // Show other buttons with fade-in
      if (retakeBtn) {
        retakeBtn.style.display = 'inline-block';
        retakeBtn.style.opacity = '0';
        setTimeout(() => {
          retakeBtn.style.opacity = '1';
          retakeBtn.style.transition = 'opacity 0.3s ease';
        }, 50);
      }
      
      if (analyzeBtn) {
        analyzeBtn.style.display = 'inline-block';
        analyzeBtn.style.opacity = '0';
        setTimeout(() => {
          analyzeBtn.style.opacity = '1';
          analyzeBtn.style.transition = 'opacity 0.3s ease';
        }, 150); // Slight delay for sequential appearance
      }
    }, 300);
  }
  
  isCaptured = true;
  
  // Stop the camera stream to save resources
  stopCamera();
}

// Retake the image with smooth transitions
function retakeImage() {
  if (!video || !canvas) return;
  
  // Hide buttons during transition
  if (retakeBtn) {
    retakeBtn.style.opacity = '0';
    retakeBtn.style.transition = 'opacity 0.3s ease';
  }
  
  if (analyzeBtn) {
    analyzeBtn.style.opacity = '0';
    analyzeBtn.style.transition = 'opacity 0.3s ease';
  }
  
  // Fade out canvas
  canvas.style.opacity = '0';
  canvas.style.transition = 'opacity 0.3s ease';
  
  setTimeout(() => {
    // Hide canvas, show video
    canvas.style.display = 'none';
    video.style.display = 'block';
    
    // Update UI with transitions
    if (retakeBtn) retakeBtn.style.display = 'none';
    if (analyzeBtn) analyzeBtn.style.display = 'none';
    
    if (captureBtn) {
      captureBtn.style.display = 'block';
      captureBtn.style.opacity = '0';
      setTimeout(() => {
        captureBtn.style.opacity = '1';
        captureBtn.style.transition = 'opacity 0.3s ease';
      }, 50);
    }
    
    isCaptured = false;
    
    // Restart camera with animation
    initCamera();
  }, 300);
}

// Analyze the captured image with enhanced UI
function analyzeImage() {
  if (!isCaptured || !canvas) return;
  
  // Show loading spinner with animation
  const loadingSpinner = document.querySelector('.loading-spinner');
  if (loadingSpinner) {
    loadingSpinner.style.display = 'block';
    loadingSpinner.classList.add('fade-in');
  }
  
  // Update analyze button state with animation
  if (analyzeBtn) {
    analyzeBtn.disabled = true;
    // Replace text with spinner while maintaining button width
    const btnWidth = analyzeBtn.offsetWidth;
    analyzeBtn.style.width = btnWidth + 'px';
    analyzeBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Analyzing...';
    
    // Add processing animation
    analyzeBtn.classList.add('processing');
    if (!document.getElementById('processing-keyframes')) {
      const style = document.createElement('style');
      style.id = 'processing-keyframes';
      style.textContent = `
        @keyframes processing-pulse {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        .processing {
          background: linear-gradient(90deg, var(--bs-info), var(--bs-primary), var(--bs-info));
          background-size: 200% 200%;
          animation: processing-pulse 2s ease infinite;
          border: none;
        }
      `;
      document.head.appendChild(style);
    }
  }
  
  // Add a subtle pulse to the canvas
  canvas.classList.add('analyzing');
  if (!document.getElementById('analyzing-keyframes')) {
    const style = document.createElement('style');
    style.id = 'analyzing-keyframes';
    style.textContent = `
      @keyframes analyzing-pulse {
        0% { transform: scale(1); }
        50% { transform: scale(0.99); }
        100% { transform: scale(1); }
      }
      .analyzing {
        animation: analyzing-pulse 1.5s ease-in-out infinite;
        box-shadow: 0 0 20px rgba(13, 202, 240, 0.5);
      }
    `;
    document.head.appendChild(style);
  }
  
  // Get the image data from canvas
  const imageData = canvas.toDataURL('image/jpeg').split(',')[1];
  
  // Add artificial delay for better UX (optional, can be removed in production)
  setTimeout(() => {
    // Send the image data to the server
    fetch('/upload-camera', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: 'image=' + encodeURIComponent(canvas.toDataURL('image/jpeg'))
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        // Show success animation before redirect
        canvas.classList.remove('analyzing');
        canvas.classList.add('success');
        if (!document.getElementById('success-keyframes')) {
          const style = document.createElement('style');
          style.id = 'success-keyframes';
          style.textContent = `
            @keyframes success-flash {
              0% { box-shadow: 0 0 0 0 rgba(76, 175, 80, 0.7); }
              70% { box-shadow: 0 0 0 20px rgba(76, 175, 80, 0); }
              100% { box-shadow: 0 0 0 0 rgba(76, 175, 80, 0); }
            }
            .success {
              animation: success-flash 1s ease-in-out;
              border: 2px solid rgba(76, 175, 80, 0.7);
            }
          `;
          document.head.appendChild(style);
        }
        
        // Add success icon overlay
        const cameraContainer = document.getElementById('camera-container');
        if (cameraContainer) {
          const successOverlay = document.createElement('div');
          successOverlay.className = 'success-overlay';
          successOverlay.style.position = 'absolute';
          successOverlay.style.top = '50%';
          successOverlay.style.left = '50%';
          successOverlay.style.transform = 'translate(-50%, -50%) scale(0)';
          successOverlay.style.width = '100px';
          successOverlay.style.height = '100px';
          successOverlay.style.background = 'rgba(76, 175, 80, 0.9)';
          successOverlay.style.borderRadius = '50%';
          successOverlay.style.display = 'flex';
          successOverlay.style.alignItems = 'center';
          successOverlay.style.justifyContent = 'center';
          successOverlay.style.zIndex = '10';
          successOverlay.style.transition = 'transform 0.3s ease-out';
          
          successOverlay.innerHTML = '<i class="fas fa-check" style="font-size: 50px; color: white;"></i>';
          
          cameraContainer.appendChild(successOverlay);
          
          setTimeout(() => {
            successOverlay.style.transform = 'translate(-50%, -50%) scale(1)';
            
            // Redirect to results page after animation
            setTimeout(() => {
              window.location.href = data.redirect;
            }, 700);
          }, 50);
        } else {
          // Immediate redirect if no animation container
          window.location.href = data.redirect;
        }
      } else {
        // Show error with animation
        canvas.classList.remove('analyzing');
        
        // Create error toast instead of alert
        const toastContainer = document.createElement('div');
        toastContainer.style.position = 'fixed';
        toastContainer.style.top = '20px';
        toastContainer.style.right = '20px';
        toastContainer.style.zIndex = '9999';
        
        const toast = document.createElement('div');
        toast.className = 'toast show';
        toast.role = 'alert';
        toast.style.background = 'var(--card-bg)';
        toast.style.color = 'white';
        toast.style.borderLeft = '4px solid var(--bs-danger)';
        toast.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.3)';
        toast.style.width = '300px';
        
        toast.innerHTML = `
          <div class="toast-header bg-danger text-white">
            <i class="fas fa-exclamation-circle me-2"></i>
            <strong class="me-auto">Error</strong>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
          </div>
          <div class="toast-body">
            ${data.error || 'Failed to analyze image'}
          </div>
        `;
        
        toastContainer.appendChild(toast);
        document.body.appendChild(toastContainer);
        
        // Auto dismiss toast
        setTimeout(() => {
          toast.classList.add('fade');
          setTimeout(() => {
            document.body.removeChild(toastContainer);
          }, 300);
        }, 5000);
        
        // Reset UI
        if (analyzeBtn) {
          analyzeBtn.disabled = false;
          analyzeBtn.textContent = 'Analyze';
          analyzeBtn.classList.remove('processing');
          analyzeBtn.style.width = 'auto';
        }
        
        if (loadingSpinner) {
          loadingSpinner.classList.add('fade-out');
          setTimeout(() => {
            loadingSpinner.style.display = 'none';
            loadingSpinner.classList.remove('fade-in', 'fade-out');
          }, 300);
        }
      }
    })
    .catch(error => {
      console.error('Error:', error);
      
      // Remove analyzing effect
      canvas.classList.remove('analyzing');
      
      // Create error toast
      const toastContainer = document.createElement('div');
      toastContainer.style.position = 'fixed';
      toastContainer.style.top = '20px';
      toastContainer.style.right = '20px';
      toastContainer.style.zIndex = '9999';
      
      const toast = document.createElement('div');
      toast.className = 'toast show';
      toast.role = 'alert';
      toast.style.background = 'var(--card-bg)';
      toast.style.color = 'white';
      toast.style.borderLeft = '4px solid var(--bs-danger)';
      toast.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.3)';
      toast.style.width = '300px';
      
      toast.innerHTML = `
        <div class="toast-header bg-danger text-white">
          <i class="fas fa-exclamation-circle me-2"></i>
          <strong class="me-auto">Error</strong>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
        </div>
        <div class="toast-body">
          An error occurred while analyzing the image. Please try again.
        </div>
      `;
      
      toastContainer.appendChild(toast);
      document.body.appendChild(toastContainer);
      
      // Auto dismiss toast
      setTimeout(() => {
        toast.classList.add('fade');
        setTimeout(() => {
          document.body.removeChild(toastContainer);
        }, 300);
      }, 5000);
      
      // Reset UI
      if (analyzeBtn) {
        analyzeBtn.disabled = false;
        analyzeBtn.textContent = 'Analyze';
        analyzeBtn.classList.remove('processing');
        analyzeBtn.style.width = 'auto';
      }
      
      if (loadingSpinner) {
        loadingSpinner.classList.add('fade-out');
        setTimeout(() => {
          loadingSpinner.style.display = 'none';
          loadingSpinner.classList.remove('fade-in', 'fade-out');
        }, 300);
      }
    });
  }, 500); // Short artificial delay for better UX
}

// Clean up camera resources when leaving the page
window.addEventListener('beforeunload', function() {
  stopCamera();
});
