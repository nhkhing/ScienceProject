// Enhanced JavaScript for PlantDoctor app with modern interactions

document.addEventListener('DOMContentLoaded', function() {
  // Initialize file upload handling
  initFileUpload();
  
  // Initialize tabs with smooth transitions
  initTabs();
  
  // Initialize tooltips
  initTooltips();
  
  // Initialize flash message auto-dismiss
  initFlashMessages();
  
  // Add scroll animations for a modern feel
  initScrollAnimations();
  
  // Add dynamic text gradients 
  initTextEffects();
});

// Initialize tabs with smooth transitions
function initTabs() {
  const tabs = document.querySelectorAll('.nav-tabs .nav-link');
  if (tabs.length > 0) {
    tabs.forEach(tab => {
      tab.addEventListener('click', function(e) {
        e.preventDefault();
        const targetId = this.getAttribute('href');
        
        // Smooth transition for tab content
        document.querySelectorAll('.tab-pane').forEach(pane => {
          if (pane.classList.contains('show')) {
            // Fade out current tab
            pane.classList.add('fade-out');
            setTimeout(() => {
              pane.classList.remove('show', 'active', 'fade-out');
              
              // Show selected tab with fade-in effect
              const targetPane = document.querySelector(targetId);
              targetPane.classList.add('show', 'active', 'fade-in');
              
              // Reset animation classes after transition
              setTimeout(() => {
                targetPane.classList.remove('fade-in');
              }, 500);
            }, 300);
          }
        });
        
        // Update active tab state
        tabs.forEach(t => t.classList.remove('active'));
        this.classList.add('active');
      });
    });
  }
}

// Initialize tooltips with custom animation
function initTooltips() {
  const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
  if (tooltipTriggerList.length > 0) {
    [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl, {
      animation: true,
      delay: { show: 100, hide: 100 }
    }));
  }
}

// Enhanced flash message handling
function initFlashMessages() {
  const flashMessages = document.querySelectorAll('.alert-dismissible');
  if (flashMessages.length > 0) {
    flashMessages.forEach(message => {
      // Add entrance animation class if not already present
      if (!message.classList.contains('animate__animated')) {
        message.classList.add('animate__animated', 'animate__fadeIn');
      }
      
      // Auto dismiss after delay
      setTimeout(() => {
        message.classList.add('animate__fadeOut');
        setTimeout(() => {
          const alert = new bootstrap.Alert(message);
          alert.close();
        }, 500);
      }, 5000);
    });
  }
}

// Add scroll animations for elements (simplified for phone optimization)
function initScrollAnimations() {
  // Only animate clickable cards
  const animateOnScroll = (entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && entry.target.querySelector('a, button')) {
        entry.target.classList.add('fade-in');
        observer.unobserve(entry.target);
      }
    });
  };

  const options = {
    root: null,
    rootMargin: '0px',
    threshold: 0.1
  };

  const observer = new IntersectionObserver(animateOnScroll, options);
  
  // Observe only cards with clickable elements
  document.querySelectorAll('.card').forEach(card => {
    if (card.querySelector('a, button')) {
      observer.observe(card);
    }
  });
}

// Add dynamic text effects only for clickable gradient texts
function initTextEffects() {
  // Add subtle hover effect only to clickable gradient texts
  const gradientTexts = document.querySelectorAll('a .text-gradient, button .text-gradient');
  if (gradientTexts) {
    gradientTexts.forEach(text => {
      if (text) {
        text.addEventListener('mouseover', () => {
          text.style.transform = 'scale(1.05)';
          text.style.transition = 'transform 0.3s ease';
        });
        
        text.addEventListener('mouseout', () => {
          text.style.transform = 'scale(1)';
        });
      }
    });
  }
}

// Enhanced file upload functionality
function initFileUpload() {
  const fileInput = document.getElementById('file-upload');
  const uploadForm = document.getElementById('upload-form');
  const uploadArea = document.querySelector('.upload-area');
  const loadingSpinner = document.querySelector('.loading-spinner');
  
  if (!fileInput || !uploadForm) return;
  
  // Handle the click on the upload area with animation
  if (uploadArea) {
    uploadArea.addEventListener('click', () => {
      uploadArea.classList.add('pulse-animation');
      setTimeout(() => {
        uploadArea.classList.remove('pulse-animation');
        fileInput.click();
      }, 300);
    });
  }
  
  // Enhanced drag and drop events
  if (uploadArea) {
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
      uploadArea.addEventListener(eventName, preventDefaults, false);
    });
    
    function preventDefaults(e) {
      e.preventDefault();
      e.stopPropagation();
    }
    
    ['dragenter', 'dragover'].forEach(eventName => {
      uploadArea.addEventListener(eventName, () => {
        uploadArea.classList.add('highlight');
        // Add subtle scale effect
        uploadArea.style.transform = 'scale(1.02)';
      }, false);
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
      uploadArea.addEventListener(eventName, () => {
        uploadArea.classList.remove('highlight');
        // Reset scale
        uploadArea.style.transform = 'scale(1)';
      }, false);
    });
    
    uploadArea.addEventListener('drop', (e) => {
      const dt = e.dataTransfer;
      fileInput.files = dt.files;
      
      // Show file name with animation
      const fileNameElement = document.getElementById('file-name');
      if (fileNameElement && fileInput.files.length > 0) {
        fileNameElement.textContent = '';
        setTimeout(() => {
          fileNameElement.textContent = fileInput.files[0].name;
          fileNameElement.classList.add('fade-in');
        }, 100);
      }
      
      // Auto-submit form on drop with slight delay for better UX
      setTimeout(submitForm, 300);
    }, false);
  }
  
  // Handle file selection via the input with enhanced feedback
  fileInput.addEventListener('change', () => {
    const fileNameElement = document.getElementById('file-name');
    if (fileNameElement && fileInput.files.length > 0) {
      fileNameElement.textContent = fileInput.files[0].name;
      fileNameElement.classList.add('fade-in');
      
      // Add visual feedback that file was selected
      if (uploadArea) {
        uploadArea.classList.add('highlight');
        setTimeout(() => {
          uploadArea.classList.remove('highlight');
        }, 800);
      }
    }
    
    // Auto-submit form on file selection with slight delay
    setTimeout(submitForm, 300);
  });
  
  // Submit the form with enhanced loading animation
  function submitForm() {
    if (fileInput.files.length > 0) {
      if (loadingSpinner) {
        loadingSpinner.style.display = 'block';
        loadingSpinner.classList.add('fade-in');
      }
      uploadForm.submit();
    }
  }
  
  // Handle the submit button with animation
  const submitButton = document.getElementById('submit-button');
  if (submitButton) {
    submitButton.addEventListener('click', (e) => {
      e.preventDefault();
      submitButton.classList.add('pulse-animation');
      setTimeout(() => {
        submitButton.classList.remove('pulse-animation');
        submitForm();
      }, 300);
    });
  }
}

// Enhanced confirm delete with modern dialog
function confirmDelete(analysisId) {
  // Create a modern styled confirm dialog
  const overlay = document.createElement('div');
  overlay.className = 'confirm-overlay';
  overlay.style.position = 'fixed';
  overlay.style.top = '0';
  overlay.style.left = '0';
  overlay.style.right = '0';
  overlay.style.bottom = '0';
  overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
  overlay.style.zIndex = '9999';
  overlay.style.display = 'flex';
  overlay.style.alignItems = 'center';
  overlay.style.justifyContent = 'center';
  overlay.style.backdropFilter = 'blur(5px)';
  overlay.style.animation = 'fadeIn 0.3s ease';
  
  const dialog = document.createElement('div');
  dialog.className = 'confirm-dialog';
  dialog.style.backgroundColor = 'var(--card-bg)';
  dialog.style.borderRadius = 'var(--border-radius)';
  dialog.style.padding = '25px';
  dialog.style.maxWidth = '400px';
  dialog.style.boxShadow = '0 15px 35px rgba(0, 0, 0, 0.5)';
  dialog.style.textAlign = 'center';
  dialog.style.animation = 'fadeIn 0.3s ease, slideUp 0.3s ease';
  dialog.style.border = '1px solid rgba(255, 255, 255, 0.1)';
  
  const title = document.createElement('h4');
  title.innerText = 'Confirm Deletion';
  title.style.marginBottom = '15px';
  
  const message = document.createElement('p');
  message.innerText = 'Are you sure you want to delete this analysis? This action cannot be undone.';
  message.style.marginBottom = '20px';
  
  const buttonContainer = document.createElement('div');
  buttonContainer.style.display = 'flex';
  buttonContainer.style.justifyContent = 'center';
  buttonContainer.style.gap = '10px';
  
  const cancelBtn = document.createElement('button');
  cancelBtn.innerText = 'Cancel';
  cancelBtn.className = 'btn btn-secondary';
  cancelBtn.addEventListener('click', () => {
    document.body.removeChild(overlay);
  });
  
  const confirmBtn = document.createElement('button');
  confirmBtn.innerText = 'Delete';
  confirmBtn.className = 'btn btn-danger';
  confirmBtn.addEventListener('click', () => {
    document.body.removeChild(overlay);
    const form = document.getElementById(`delete-form-${analysisId}`);
    if (form) {
      form.submit();
    }
  });
  
  buttonContainer.appendChild(cancelBtn);
  buttonContainer.appendChild(confirmBtn);
  
  dialog.appendChild(title);
  dialog.appendChild(message);
  dialog.appendChild(buttonContainer);
  overlay.appendChild(dialog);
  
  document.body.appendChild(overlay);
  
  // Add animation keyframes to document
  const style = document.createElement('style');
  style.textContent = `
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    @keyframes slideUp {
      from { transform: translateY(50px); }
      to { transform: translateY(0); }
    }
    @keyframes pulse-animation {
      0% { transform: scale(1); }
      50% { transform: scale(1.05); }
      100% { transform: scale(1); }
    }
    .pulse-animation {
      animation: pulse-animation 0.4s ease;
    }
  `;
  document.head.appendChild(style);
}
