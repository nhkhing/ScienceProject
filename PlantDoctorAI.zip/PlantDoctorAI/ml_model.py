import os
import logging
import random
from PIL import Image

logger = logging.getLogger(__name__)

# Dictionary of potato diseases with their descriptions and recommendations
POTATO_DISEASES = {
    'Early blight': {
        'description': 'Early blight is a fungal disease caused by Alternaria solani. It appears as dark brown to black lesions with concentric rings, forming a "target spot" pattern.',
        'recommendations': [
            'Remove and destroy infected plant parts',
            'Ensure adequate plant spacing for good air circulation',
            'Apply copper-based fungicides as a preventative measure',
            'Use crop rotation with non-solanaceous crops',
            'Maintain plant vigor through proper fertilization and irrigation'
        ]
    },
    'Late blight': {
        'description': 'Late blight is a devastating disease caused by the oomycete Phytophthora infestans. It causes water-soaked lesions that rapidly enlarge and turn dark brown to purplish-black.',
        'recommendations': [
            'Apply fungicides preventatively before symptoms appear',
            'Plant resistant varieties when available',
            'Remove volunteer potato plants and nightshade family weeds',
            'Destroy all infected plants immediately',
            'Avoid overhead irrigation and irrigate in the morning so plants dry quickly'
        ]
    },
    'Healthy': {
        'description': 'This plant appears healthy with no visible signs of disease.',
        'recommendations': [
            'Continue regular monitoring for early signs of disease',
            'Maintain proper irrigation and fertilization practices',
            'Follow preventative spraying schedules for your region',
            'Practice crop rotation each growing season',
            'Remove nearby weeds that may harbor pests or pathogens'
        ]
    }
}

class PotatoDiseaseModel:
    def __init__(self):
        """Initialize the model for potato disease detection"""
        self.model = None
        self.class_names = ['Early blight', 'Late blight', 'Healthy']
        self.img_size = (224, 224)  # Standard input size
        
    def load(self):
        """
        Load the pre-trained model or create and train a new one.
        In a production environment, we would load a pre-trained model.
        """
        try:
            # For this demo, we'll create a simple model - in production, you'd load a pre-trained model
            if self.model is None:
                self._create_model()
            logger.info("Model loaded successfully")
            return True
        except Exception as e:
            logger.error(f"Error loading model: {str(e)}")
            return False
    
    def _create_model(self):
        """Create a simulated model"""
        # In a real application, this would create or load a TensorFlow/PyTorch model
        # For the demo, we'll just set a flag
        self.model = True
        logger.info("Model created successfully")
    
    def preprocess_image(self, img_path):
        """Preprocess the image for model prediction"""
        try:
            # Open the image 
            img = Image.open(img_path)
            # Resize it to our standard size
            img = img.resize(self.img_size)
            
            logger.info(f"Image {img_path} processed successfully")
            return True
        except Exception as e:
            logger.error(f"Error preprocessing image: {str(e)}")
            return None
    
    def predict(self, img_path):
        """
        Predict the disease in the potato plant image
        
        Args:
            img_path: Path to the uploaded image
            
        Returns:
            Dictionary with prediction results
        """
        if self.model is None and not self.load():
            return {
                'success': False,
                'error': 'Model not loaded'
            }
        
        try:
            # Preprocess the image
            processed = self.preprocess_image(img_path)
            if processed is None:
                return {
                    'success': False,
                    'error': 'Failed to process image'
                }
            
            # Simulate model prediction - in production this would be real predictions
            # This is just for demonstration purposes
            # For simplicity, we'll return different results based on the filename
            filename = os.path.basename(img_path).lower()
            
            # Simulated prediction logic - would be replaced with actual model.predict() in production
            if 'early' in filename:
                disease_index = 0  # Early blight
                confidence = 0.92
            elif 'late' in filename:
                disease_index = 1  # Late blight
                confidence = 0.88
            else:
                # If image name doesn't contain clues, pick randomly but favor healthy
                r = random.random()
                if r < 0.4:
                    disease_index = 0  # Early blight
                    confidence = 0.78 + (r * 0.1)
                elif r < 0.7:
                    disease_index = 1  # Late blight
                    confidence = 0.75 + (r * 0.15)
                else:
                    disease_index = 2  # Healthy
                    confidence = 0.85 + (r * 0.1)
            
            disease = self.class_names[disease_index]
            disease_info = POTATO_DISEASES.get(disease, {
                'description': 'No information available for this condition.',
                'recommendations': ['Consult with a plant pathologist for accurate diagnosis.']
            })
            
            return {
                'success': True,
                'disease': disease,
                'confidence': float(confidence),
                'description': disease_info['description'],
                'recommendations': disease_info['recommendations']
            }
            
        except Exception as e:
            logger.error(f"Prediction error: {str(e)}")
            return {
                'success': False,
                'error': f'Prediction failed: {str(e)}'
            }

# Create singleton instance
potato_disease_model = PotatoDiseaseModel()
