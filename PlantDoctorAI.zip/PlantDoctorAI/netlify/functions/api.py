from flask import Flask, Response
import sys
import os
import json
import base64
import io
from urllib.parse import parse_qs

# Set Netlify environment flag
os.environ['NETLIFY'] = 'true'

# Add the project root to the Python path so we can import our app
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Import the Flask app from main.py
from main import app as flask_app

def handler(event, context):
    """Netlify Function handler to run the Flask app"""
    # Set function timeout and prevent Lambda from waiting
    if context:
        context.callbackWaitsForEmptyEventLoop = False
    
    try:
        # Extract request data from the event
        path = event.get('path', '').lstrip('/')
        http_method = event.get('httpMethod', '')
        
        headers = event.get('headers', {}) or {}
        headers_lower = {k.lower(): v for k, v in headers.items() if k is not None}
        
        # Get multiValueQueryStringParameters for proper query string handling
        multi_query = event.get('multiValueQueryStringParameters', {}) or {}
        query_string = ''
        if multi_query:
            query_parts = []
            for key, values in multi_query.items():
                for value in values:
                    query_parts.append(f"{key}={value}")
            query_string = '&'.join(query_parts)
        else:
            # Fallback to standard queryStringParameters
            single_query = event.get('queryStringParameters', {}) or {}
            if single_query:
                query_string = '&'.join([f"{k}={v}" for k, v in single_query.items()])
        
        # Handle request body, supporting both binary and text
        body = event.get('body', '')
        is_base64_encoded = event.get('isBase64Encoded', False)
        
        if is_base64_encoded and body:
            body = base64.b64decode(body)
        
        # Create a file-like object for wsgi.input if body exists
        wsgi_input = io.BytesIO(body.encode('utf-8')) if isinstance(body, str) and body else io.BytesIO(body if isinstance(body, bytes) else b'')
        
        # Handle form data for POST requests
        content_type = headers_lower.get('content-type', '')
        if http_method == 'POST' and 'application/x-www-form-urlencoded' in content_type and body:
            # Parse form data and add to environ
            if isinstance(body, str):
                form_data = parse_qs(body)
            elif isinstance(body, bytes):
                form_data = parse_qs(body.decode('utf-8'))
            elif isinstance(body, memoryview):
                form_data = parse_qs(bytes(body).decode('utf-8'))
            else:
                form_data = {}
            # Flask will extract form data from wsgi.input
        
        # Prepare the WSGI environment
        environ = {
            'REQUEST_METHOD': http_method,
            'PATH_INFO': f'/{path}',
            'QUERY_STRING': query_string,
            'CONTENT_LENGTH': headers_lower.get('content-length', '0'),
            'CONTENT_TYPE': content_type,
            'HTTP_COOKIE': headers_lower.get('cookie', ''),
            'HTTP_HOST': headers_lower.get('host', ''),
            'HTTP_USER_AGENT': headers_lower.get('user-agent', ''),
            'HTTP_X_FORWARDED_FOR': headers_lower.get('x-forwarded-for', ''),
            'HTTP_X_FORWARDED_PROTO': 'https',
            'wsgi.input': wsgi_input,
            'wsgi.errors': sys.stderr,
            'wsgi.version': (1, 0),
            'wsgi.multithread': False,
            'wsgi.multiprocess': False,
            'wsgi.run_once': False,
            'wsgi.url_scheme': 'https',
            'SERVER_NAME': headers_lower.get('host', 'localhost'),
            'SERVER_PORT': '443',
            'SERVER_PROTOCOL': 'HTTP/1.1',
            'SCRIPT_NAME': '',  # Important for Flask routing
        }
        
        # Add all HTTP_ headers
        for key, value in headers_lower.items():
            key = key.upper().replace('-', '_')
            if key not in ('CONTENT_LENGTH', 'CONTENT_TYPE'):
                environ[f'HTTP_{key}'] = value
        
        # Create response object to capture the Flask response
        response = {'statusCode': 200, 'headers': {}, 'body': '', 'isBase64Encoded': False}
        
        # Buffer to collect response data
        response_data = []
        
        def start_response(status, response_headers, exc_info=None):
            status_code = int(status.split()[0])
            response['statusCode'] = status_code
            response['headers'] = {key: value for key, value in response_headers}
            
            # Add CORS headers
            if 'Access-Control-Allow-Origin' not in response['headers']:
                response['headers']['Access-Control-Allow-Origin'] = '*'
            if http_method == 'OPTIONS' and 'Access-Control-Allow-Methods' not in response['headers']:
                response['headers']['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
                response['headers']['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
                response['headers']['Access-Control-Max-Age'] = '86400'
            
            return lambda x: response_data.append(x)
        
        # Run the Flask app
        result = flask_app(environ, start_response)
        
        # Collect all response chunks
        for data in result:
            if data:
                response_data.append(data)
        
        # Check if we need to return binary data (like images)
        content_type = response['headers'].get('Content-Type', '')
        is_binary = any(binary_type in content_type for binary_type in [
            'image/', 'audio/', 'video/', 'application/octet-stream', 'application/pdf',
            'application/zip', 'font/', 'application/gzip'
        ])
        
        if is_binary:
            # Convert binary response to base64
            binary_body = b''.join(response_data)
            response['body'] = base64.b64encode(binary_body).decode('utf-8')
            response['isBase64Encoded'] = True
        else:
            # Convert text response to string
            text_body = b''.join(response_data).decode('utf-8')
            response['body'] = text_body
        
        return response
        
    except Exception as e:
        # Handle any errors
        print(f"Error in Lambda function: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': str(e),
                'message': 'Internal Server Error'
            })
        }