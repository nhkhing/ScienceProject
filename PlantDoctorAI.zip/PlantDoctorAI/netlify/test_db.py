"""
Database connection test utility for Netlify deployment.
Run this script locally or in the Netlify environment to verify
database connectivity.
"""

import os
import sys
import time
from sqlalchemy import create_engine, text

def test_connection(database_url=None):
    """Test database connection with the provided URL or environment variable"""
    # Get database URL from environment if not provided
    db_url = database_url or os.environ.get('DATABASE_URL')
    
    if not db_url:
        print("Error: No DATABASE_URL provided.")
        print("Please set the DATABASE_URL environment variable or pass as argument.")
        return False
    
    # Postgres on Heroku uses a different URL format
    if db_url.startswith("postgres://"):
        db_url = db_url.replace("postgres://", "postgresql://", 1)
    
    print(f"Testing connection to database...")
    
    try:
        # Create engine with SSL required for most cloud database providers
        engine = create_engine(
            db_url,
            connect_args={"sslmode": "require"} if not os.environ.get("DEVELOPMENT") else {}
        )
        
        # Try to connect and run a simple query
        with engine.connect() as conn:
            result = conn.execute(text("SELECT 1"))
            row = result.fetchone()
            if row and row[0] == 1:
                print("✅ Database connection successful!")
                
                # Get database metadata
                db_info_query = text("""
                SELECT current_database() as db_name, 
                       current_schema() as schema,
                       current_user as user,
                       version() as version
                """)
                db_info = conn.execute(db_info_query).fetchone()
                print("\nDatabase Information:")
                print(f"Database Name: {db_info.db_name}")
                print(f"Schema: {db_info.schema}")
                print(f"User: {db_info.user}")
                print(f"Version: {db_info.version}")
                
                return True
            else:
                print("❌ Unknown error: Database connected but test query failed.")
                return False
    except Exception as e:
        print(f"❌ Error connecting to database: {str(e)}")
        return False

if __name__ == "__main__":
    # If database URL is provided as command line argument, use it
    db_url = sys.argv[1] if len(sys.argv) > 1 else None
    
    # Try to connect with retries
    max_retries = 3
    for i in range(max_retries):
        if test_connection(db_url):
            sys.exit(0)
        
        if i < max_retries - 1:
            retry_delay = 2 ** i  # Exponential backoff: 1, 2, 4 seconds
            print(f"Retrying in {retry_delay} seconds... (Attempt {i+1}/{max_retries})")
            time.sleep(retry_delay)
    
    print("Failed to connect to database after multiple attempts.")
    sys.exit(1)